package dev.missy.switchy_puffish_skills.modules;

import folk.sisby.switchy.api.SwitchySerializable;
import net.minecraft.class_2487;
import net.minecraft.class_2960;

public class PufferfishSkillsModuleData implements SwitchySerializable {
    public static final String KEY_SKILLS_DATA = "skills_data";
    protected static final class_2960 ID = class_2960.method_60655("switchy_puffish_skills", "pufferfish_skills");
    protected class_2487 skillsData = new class_2487();

    @Override
    public class_2487 toNbt() {
        class_2487 outNbt = new class_2487();
        outNbt.method_10566(KEY_SKILLS_DATA, skillsData);
        return outNbt;
    }

    @Override
    public void fillFromNbt(class_2487 nbt) {
        this.skillsData = nbt.method_10562(KEY_SKILLS_DATA);
    }
}
